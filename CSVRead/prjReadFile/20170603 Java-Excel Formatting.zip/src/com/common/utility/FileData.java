package com.common.utility;


public class FileData {
	public String JDBC_CONNECTION_URL = "";
	//"jdbc:sqlserver://127.0.0.1:1433;instance=SQLEXPRESS;databaseName=Stock;";
	public String DRIVER= "";
	public String User="";
	public String Password="";
	public String SourceFile="";
	public String TargetFile="";
	public String Step1Table="";
	public String Step2Table = "";
}
